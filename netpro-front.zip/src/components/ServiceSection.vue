<template>
    <section class="service-section py-12 lg:py-20 overflow-clip">
        <div class="container mx-auto px-4 ">
            <div class="flex flex-col lg:flex-row lg:gap-8 lg:justify-between ">
                <div class="col order-last lg:order-first" :class="{'lg:order-last': flip}">
                    <div class="content">
                        <motion.div class="title mb-2" :initial="{opacity: 0, y: 100 }" :whileInView="{opacity: 1, y: 0, transition: { duration: 0.5 } }" :inViewOptions="{ once: true }">
                            {{title}}
                        </motion.div>
                        <ul class="tech-list my-2 lg:my-12">
                            <MotionConfig :transition="{ duration: 1, delay: 0.75 }">
                                <motion.li v-for="(li, index) in list" :key="index" :initial="{opacity: 0, y: 50}" :whileInView="{opacity: 1, y: 0}" :inViewOptions="{ once: true }" class="flex justify-between">{{li}} </motion.li>
                            </MotionConfig>
                        </ul>
                        <motion.div :initial="{opacity: 0, y: 50}" :whileInView="{opacity: 1, y: 0, transition: { duration: 0.5, delay: 0.75}}" :inViewOptions="{ once: true }" class="mt-6 ">
                            <router-link :to="link.path" class="tech-link inline-flex gap-4">{{link.text}} <img src="/icons/arrow-right-blue.svg" alt=""></router-link>
                        </motion.div>
                    </div>
                </div>
                <div class="col lg:w-1/2  " >
                    <motion.figure :initial="{y: '20%', opacity: 0}" :whileInView="{opacity: 1, y: 0, transition: {ease: 'easeOut', duration: 1, delay: 1}}" class="max-w-[660px] rounded-xl overflow-clip mb-8 lg:mb-4">
                        <img :src="image" class="max-w-full" alt="">
                    </motion.figure>
                </div>
            </div>
        </div>
    </section>
</template>
<script setup>
import { ref, onMounted } from 'vue'
import { motion, MotionConfig } from "motion-v"

const props = defineProps({
    title: { type: String, default: "Technology Connection" },
    image: { type: String },
    list: {
        type: Array,
        default: () => {
            return ["item1"]
        }
    },
    link: {
        type: Object,
        default: () => {
            return { text: "Explore", path: "/service" }
        }
    },
    flip: false
})

onMounted(() => {
    // bUrl.value = localStorage.getItem("base_url")
})
</script>
<style lang="scss" scoped>
.service-section {
    color: $rich-black;

    .content {
        max-width: 400px;
    }

    .title {
        font-size: 24px;
        font-style: normal;
        font-weight: 100;
        line-height: 32px;
        letter-spacing: -0.72px;

    }

    .tech-list {
        color: $rich-black;

        font-size: 16px;
        font-style: normal;
        font-weight: 600;
        line-height: 60px;
        letter-spacing: -0.48px;

        li {

            border-bottom: 1px solid #D7D7D7;

            &::after {
                content: url('/icons/arrow-right-blue.svg');
                opacity: 0;
                transition: opacity 400ms ease-in;
            }

        }
    }

    .tech-link {

        font-size: 14px;
        font-style: normal;
        font-weight: 400;
        line-height: 24px;
        letter-spacing: -0.42px;

        background: linear-gradient(98deg, #171EEC 7.56%, #7000D9 93.65%);
        background-clip: text;
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;

        img {
            transition: margin 400ms ease-out;
        }

        &:hover {
            img {
                margin-left: 1rem;
            }
        }
    }

    @media screen and (width >=64rem) {
        .title {

            font-size: 40px;
            line-height: 60px;
            letter-spacing: -1.2px;
        }

        .tech-list {
            font-size: 20px;
            font-weight: 600;
            line-height: 80px;
            letter-spacing: -0.6px;

            li {
                &::after {
                    opacity: 0;
                }

                &:hover {

                    &::after {
                        opacity: 1;
                    }
                }

            }
        }
        .tech-link {
            font-size: 16px;
            line-height: 30px;
        }
    }
}
</style>