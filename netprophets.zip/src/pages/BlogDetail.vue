<template>
	<h1>Blog detail page</h1>
</template>

<script setup>
import { ref } from 'vue'
  
</script>

<style lang="scss" scoped>
</style>